-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: labmap
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `maintenance`
--

DROP TABLE IF EXISTS `maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenance` (
  `wo_id` int NOT NULL,
  `submitted_time` datetime DEFAULT NULL,
  `date_finished` datetime DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `tester` varchar(45) DEFAULT NULL,
  `peripheral` varchar(45) DEFAULT NULL,
  `requestor` varchar(45) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`wo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance`
--

LOCK TABLES `maintenance` WRITE;
/*!40000 ALTER TABLE `maintenance` DISABLE KEYS */;
INSERT INTO `maintenance` VALUES (1,'2023-03-31 19:30:37',NULL,'Active','Coca-Cola','None','7198','Testing'),(2,'2023-03-31 19:30:37','2023-04-20 19:30:37','Closed','Coca-Cola','None','7198','Testing'),(3,'2023-05-13 05:15:34','2023-05-17 03:54:59','Closed','Coca-Cola','None','7198','Testing\nUPDATE 2023-05-17 03:54:59: ky fixed the tester PC to have it stop blue screening'),(4,'2023-05-13 05:40:18',NULL,'Active','Dr. Pepper','M4872','7198','Debug'),(5,'2023-05-13 06:52:50',NULL,'Active','Tekken','HA7300','7198','Currently testing this'),(6,'2023-05-17 02:26:27','2023-05-17 03:59:28','Closed','Skullgirls','M4171','7198','Quickly testing this\nUPDATE 2023-05-17 03:59:27: Hi maintenance at night shift could not resolve alignment issue on M4171 at this tester.'),(7,'2023-05-17 04:26:29','2023-05-18 15:10:39','Closed','Guilty Gear','M4171','7198','Hi team, M4171 is having alignment issues and the handler is breaking devices, please take a look\nUPDATE 2023-05-18 15:10:22: Hi team this is a test\nUPDATE 2023-05-18 15:10:39: Hi team this is fixed'),(8,'2023-05-18 14:25:12','2023-05-18 14:29:00','Closed','Pepsi','M4171','7198','Hello, the handler cannot reach -65C and this is the final project.\nUPDATE 2023-05-18 14:25:39: This is an update\nUPDATE 2023-05-18 14:25:51: This is finished\nUPDATE 2023-05-18 14:29:00: Actually closed now!'),(9,'2023-05-18 14:35:10','2023-05-18 14:37:05','Closed','Fanta','Manual Socket','7198','PC keeps blue screening\nUPDATE 2023-05-18 14:35:38: IT checked, but could not determine the issue.\nUPDATE 2023-05-18 14:37:04: IT reinstalled Windows to solve the issue.'),(10,'2023-05-18 15:11:33',NULL,'Active','MvC','HA7300','7198','Hi team this handler cannot reach -65C properly, can you check the chiller?');
/*!40000 ALTER TABLE `maintenance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-03  5:44:12
